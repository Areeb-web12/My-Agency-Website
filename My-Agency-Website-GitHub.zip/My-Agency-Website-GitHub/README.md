# My Agency Website

A full-stack agency website project with a React/Vite frontend and Node.js backend.

## Project Structure

```text
app/       Frontend website
backend/   Backend server and contact route
```

## Frontend

```bash
cd app
npm install
npm run dev
```

## Backend

```bash
cd backend
npm install
node server.js
```

## Author

Areeb-web12
