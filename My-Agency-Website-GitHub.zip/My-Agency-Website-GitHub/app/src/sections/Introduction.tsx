import { Target, TrendingUp, Shield } from 'lucide-react'

export default function Introduction() {
  return (
    <section className="py-20 lg:py-28 bg-[#0a0f1a]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid lg:grid-cols-2 gap-12 lg:gap-16 items-center">
          {/* Content */}
          <div>
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-cyan-500/10 border border-cyan-500/20 mb-6">
              <Target className="w-4 h-4 text-cyan-400" />
              <span className="text-sm text-cyan-400 font-medium">Our Mission</span>
            </div>

            <h2 className="text-3xl sm:text-4xl lg:text-5xl font-bold text-white mb-6 leading-tight">
              Help businesses grow by finding their{' '}
              <span className="text-gradient">next customers</span>
            </h2>

            <div className="space-y-4 text-gray-400 text-lg leading-relaxed">
              <p>
                At The Data Harbour, our mission is simple:{' '}
                <span className="text-white font-medium">
                  Help businesses grow by finding their next customers.
                </span>
              </p>
              <p>
                We build verified prospect databases, structured outreach systems, CRM workflows, 
                and automation solutions designed to deliver consistent and measurable results.
              </p>
              <p>
                Before scaling any project, we recommend starting with a small sample batch so you can 
                evaluate data quality and accuracy first.
              </p>
            </div>

            <div className="mt-8 p-4 rounded-xl bg-gradient-to-r from-cyan-500/10 to-blue-500/10 border border-cyan-500/20">
              <p className="text-cyan-400 font-semibold text-lg">
                "Growth should be predictable, structured, and data-backed."
              </p>
            </div>
          </div>

          {/* Features Grid */}
          <div className="grid sm:grid-cols-2 gap-4">
            {[
              {
                icon: Target,
                title: 'Verified Prospects',
                description: 'Every lead is accuracy-checked and verified for better outreach performance.',
              },
              {
                icon: TrendingUp,
                title: 'Structured Systems',
                description: 'CRM workflows and automation solutions for consistent results.',
              },
              {
                icon: Shield,
                title: 'Quality First',
                description: 'Start with sample batches to evaluate data quality before scaling.',
              },
              {
                icon: Target,
                title: 'Measurable Growth',
                description: 'Data-backed strategies that deliver predictable outcomes.',
              },
            ].map((feature, index) => (
              <div
                key={index}
                className="p-6 rounded-2xl bg-white/[0.02] border border-white/5 hover:border-cyan-500/30 hover:bg-white/[0.04] transition-all group"
              >
                <div className="w-12 h-12 rounded-xl bg-cyan-500/10 flex items-center justify-center mb-4 group-hover:bg-cyan-500/20 transition-all">
                  <feature.icon className="w-6 h-6 text-cyan-400" />
                </div>
                <h3 className="text-lg font-semibold text-white mb-2">{feature.title}</h3>
                <p className="text-sm text-gray-500 leading-relaxed">{feature.description}</p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  )
}
