import { Wrench, Check } from 'lucide-react'

const dataPlatforms = [
  'Apollo.io',
  'LinkedIn Sales Navigator',
  'Clearbit',
  'SignalHire',
  'GetEmail',
  'RocketReach',
  'Cognism',
  'Snovio',
  'Hunter.io',
  'Crunchbase PRO',
  'ZoomInfo',
]

const verificationTools = [
  'NeverBounce',
  'ZeroBounce',
  'Reoon Email Verifier',
  'Million Verifier',
]

export default function Tools() {
  return (
    <section className="py-20 lg:py-28 bg-[#0d121f]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="text-center mb-16">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-cyan-500/10 border border-cyan-500/20 mb-6">
            <Wrench className="w-4 h-4 text-cyan-400" />
            <span className="text-sm text-cyan-400 font-medium">Our Tech Stack</span>
          </div>
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-bold text-white mb-4">
            Tools We Use
          </h2>
          <p className="max-w-2xl mx-auto text-gray-400 text-lg">
            We use premium data platforms to ensure accuracy and deliverability
          </p>
        </div>

        <div className="grid lg:grid-cols-2 gap-8">
          {/* Data Platforms */}
          <div className="p-8 rounded-2xl bg-white/[0.02] border border-white/5">
            <h3 className="text-xl font-semibold text-white mb-6 flex items-center gap-3">
              <div className="w-10 h-10 rounded-lg bg-cyan-500/10 flex items-center justify-center">
                <Check className="w-5 h-5 text-cyan-400" />
              </div>
              Premium Data Platforms
            </h3>
            <div className="grid grid-cols-2 gap-3">
              {dataPlatforms.map((tool, index) => (
                <div
                  key={index}
                  className="flex items-center gap-2 p-3 rounded-lg bg-white/[0.02] border border-white/5 hover:border-cyan-500/30 transition-all"
                >
                  <div className="w-2 h-2 rounded-full bg-cyan-400" />
                  <span className="text-sm text-gray-300">{tool}</span>
                </div>
              ))}
            </div>
          </div>

          {/* Email Verification Tools */}
          <div className="p-8 rounded-2xl bg-white/[0.02] border border-white/5">
            <h3 className="text-xl font-semibold text-white mb-6 flex items-center gap-3">
              <div className="w-10 h-10 rounded-lg bg-cyan-500/10 flex items-center justify-center">
                <Check className="w-5 h-5 text-cyan-400" />
              </div>
              Email Verification Tools
            </h3>
            <div className="grid grid-cols-2 gap-3">
              {verificationTools.map((tool, index) => (
                <div
                  key={index}
                  className="flex items-center gap-2 p-3 rounded-lg bg-white/[0.02] border border-white/5 hover:border-cyan-500/30 transition-all"
                >
                  <div className="w-2 h-2 rounded-full bg-cyan-400" />
                  <span className="text-sm text-gray-300">{tool}</span>
                </div>
              ))}
            </div>

            <div className="mt-6 p-4 rounded-xl bg-gradient-to-r from-cyan-500/10 to-blue-500/10 border border-cyan-500/20">
              <p className="text-sm text-gray-400">
                Along with advanced research techniques across directories and verified databases.
              </p>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}
