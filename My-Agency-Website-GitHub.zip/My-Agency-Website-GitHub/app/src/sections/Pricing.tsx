import { DollarSign, Users, Calendar, Check, ArrowRight } from 'lucide-react'
import { Button } from '@/components/ui/button'

const pricingModels = [
  {
    icon: DollarSign,
    title: 'Hourly Engagement',
    price: '$5',
    unit: 'per hour',
    description: 'Ideal for research, CRM updates, automation setup, and administrative support.',
    features: [
      'Flexible hours',
      'Research tasks',
      'CRM updates',
      'Automation setup',
      'Administrative support',
    ],
    highlighted: false,
  },
  {
    icon: Users,
    title: 'Pay-Per-Lead Model',
    price: 'Custom',
    unit: 'pricing',
    description: 'Pricing depends on lead volume, industry type, research complexity, and data verification depth.',
    features: [
      'Lead volume based',
      'Industry specific',
      'Research complexity',
      'Data verification',
      'Accuracy guaranteed',
    ],
    highlighted: true,
  },
  {
    icon: Calendar,
    title: 'Monthly / Weekly Retainer',
    price: 'Custom',
    unit: 'retainer',
    description: 'For businesses seeking consistent pipeline growth with ongoing support.',
    features: [
      'Ongoing lead generation',
      'Outreach campaigns',
      'CRM management',
      'Research & automation',
      'Regular data updates',
    ],
    highlighted: false,
  },
]

export default function Pricing() {
  const scrollToContact = () => {
    const element = document.querySelector('#contact')
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' })
    }
  }

  return (
    <section className="py-20 lg:py-28 bg-[#0a0f1a]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="text-center mb-16">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-cyan-500/10 border border-cyan-500/20 mb-6">
            <DollarSign className="w-4 h-4 text-cyan-400" />
            <span className="text-sm text-cyan-400 font-medium">Pricing</span>
          </div>
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-bold text-white mb-4">
            Flexible Engagement Models
          </h2>
          <p className="max-w-2xl mx-auto text-gray-400 text-lg">
            We offer structured pricing options based on your needs
          </p>
        </div>

        {/* Pricing Cards */}
        <div className="grid md:grid-cols-3 gap-6 lg:gap-8">
          {pricingModels.map((model, index) => (
            <div
              key={index}
              className={`relative p-8 rounded-2xl border transition-all duration-300 ${
                model.highlighted
                  ? 'bg-gradient-to-b from-cyan-500/10 to-blue-500/10 border-cyan-500/30 scale-105'
                  : 'bg-white/[0.02] border-white/5 hover:border-white/10'
              }`}
            >
              {model.highlighted && (
                <div className="absolute -top-4 left-1/2 -translate-x-1/2 px-4 py-1 rounded-full bg-gradient-to-r from-cyan-500 to-blue-600 text-white text-sm font-medium">
                  Most Popular
                </div>
              )}

              <div className="w-12 h-12 rounded-xl bg-cyan-500/10 flex items-center justify-center mb-6">
                <model.icon className="w-6 h-6 text-cyan-400" />
              </div>

              <h3 className="text-xl font-semibold text-white mb-2">{model.title}</h3>

              <div className="flex items-baseline gap-1 mb-4">
                <span className="text-4xl font-bold text-white">{model.price}</span>
                <span className="text-gray-500">{model.unit}</span>
              </div>

              <p className="text-gray-400 text-sm mb-6 leading-relaxed">{model.description}</p>

              <ul className="space-y-3 mb-8">
                {model.features.map((feature, fIndex) => (
                  <li key={fIndex} className="flex items-center gap-3 text-sm text-gray-300">
                    <Check className="w-4 h-4 text-cyan-400 flex-shrink-0" />
                    {feature}
                  </li>
                ))}
              </ul>

              <Button
                onClick={scrollToContact}
                className={`w-full group ${
                  model.highlighted
                    ? 'bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 text-white'
                    : 'bg-white/5 hover:bg-white/10 text-white border border-white/10'
                }`}
              >
                Get Started
                <ArrowRight className="ml-2 w-4 h-4 group-hover:translate-x-1 transition-transform" />
              </Button>
            </div>
          ))}
        </div>

        {/* Note */}
        <div className="mt-12 text-center">
          <p className="text-gray-500">
            Final pricing is discussed after understanding your targeting criteria.
          </p>
        </div>
      </div>
    </section>
  )
}
