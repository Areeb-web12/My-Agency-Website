import { Award, Zap, Building2, Handshake, Check } from 'lucide-react'

const reasons = [
  {
    icon: Award,
    title: 'Proven Expertise',
    description: 'Skilled in premium tools, including LinkedIn Sales Navigator, Apollo, ZoomInfo, and more.',
  },
  {
    icon: Zap,
    title: 'Efficiency & Accuracy',
    description: 'We prioritize verified and reliable data for better outreach performance.',
  },
  {
    icon: Building2,
    title: 'Diverse Industry Experience',
    description: 'From e-commerce to real estate and beyond.',
  },
  {
    icon: Handshake,
    title: 'Long-Term Collaboration',
    description: 'Focused on building stable, ongoing partnerships.',
  },
]

export default function WhyHireUs() {
  const scrollToContact = () => {
    const element = document.querySelector('#contact')
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' })
    }
  }

  return (
    <section className="py-20 lg:py-28 bg-[#0d121f]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="text-center mb-16">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-cyan-500/10 border border-cyan-500/20 mb-6">
            <Award className="w-4 h-4 text-cyan-400" />
            <span className="text-sm text-cyan-400 font-medium">Why Choose Us</span>
          </div>
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-bold text-white mb-4">
            Why Hire Us?
          </h2>
        </div>

        {/* Reasons Grid */}
        <div className="grid md:grid-cols-2 gap-6 mb-12">
          {reasons.map((reason, index) => (
            <div
              key={index}
              className="group p-8 rounded-2xl bg-white/[0.02] border border-white/5 hover:border-cyan-500/30 hover:bg-white/[0.04] transition-all duration-300"
            >
              <div className="w-14 h-14 rounded-xl bg-cyan-500/10 flex items-center justify-center mb-6 group-hover:bg-cyan-500/20 group-hover:scale-110 transition-all">
                <reason.icon className="w-7 h-7 text-cyan-400" />
              </div>
              <h3 className="text-xl font-semibold text-white mb-3 group-hover:text-cyan-400 transition-colors">
                {reason.title}
              </h3>
              <p className="text-gray-400 leading-relaxed">{reason.description}</p>
            </div>
          ))}
        </div>

        {/* CTA Box */}
        <div className="p-8 rounded-2xl bg-gradient-to-r from-cyan-500/10 to-blue-500/10 border border-cyan-500/20">
          <div className="flex flex-col md:flex-row items-center justify-between gap-6">
            <div className="flex items-start gap-4">
              <div className="w-12 h-12 rounded-xl bg-cyan-500/20 flex items-center justify-center flex-shrink-0">
                <Check className="w-6 h-6 text-cyan-400" />
              </div>
              <div>
                <h4 className="text-lg font-semibold text-white mb-2">
                  Start with a Sample Batch
                </h4>
                <p className="text-gray-400">
                  Before scaling, we recommend starting with a small sample batch so you can evaluate quality first.
                </p>
              </div>
            </div>
            <button
              onClick={scrollToContact}
              className="px-6 py-3 rounded-xl bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 text-white font-medium transition-all whitespace-nowrap"
            >
              Get Started Today
            </button>
          </div>
        </div>
      </div>
    </section>
  )
}
