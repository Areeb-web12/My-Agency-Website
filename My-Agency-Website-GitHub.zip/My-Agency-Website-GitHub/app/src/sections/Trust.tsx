import { Check, Clock, Award, Globe } from 'lucide-react'

const trustPoints = [
  {
    icon: Clock,
    text: '8+ Years of Experience',
  },
  {
    icon: Check,
    text: '12,000+ Hours Completed',
  },
  {
    icon: Award,
    text: '100% Commitment to Accuracy & Quality',
  },
  {
    icon: Globe,
    text: 'Global Client Support',
  },
]

export default function Trust() {
  return (
    <section className="py-12 bg-[#0d121f] border-y border-white/5">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-2 md:grid-cols-4 gap-6 md:gap-8">
          {trustPoints.map((point, index) => (
            <div
              key={index}
              className="flex items-center gap-3 p-4 rounded-xl bg-white/[0.02] border border-white/5 hover:border-cyan-500/30 hover:bg-white/[0.04] transition-all group"
            >
              <div className="w-10 h-10 rounded-lg bg-cyan-500/10 flex items-center justify-center flex-shrink-0 group-hover:bg-cyan-500/20 transition-all">
                <point.icon className="w-5 h-5 text-cyan-400" />
              </div>
              <span className="text-sm font-medium text-gray-300 group-hover:text-white transition-colors">
                {point.text}
              </span>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
