import { Mail, Phone, MapPin, Facebook, Linkedin, Calendar, ArrowRight, MessageCircle } from 'lucide-react'
import { Button } from '@/components/ui/button'

export default function Contact() {
  return (
    <section className="py-20 lg:py-28 bg-[#0a0f1a]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="text-center mb-16">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-cyan-500/10 border border-cyan-500/20 mb-6">
            <MessageCircle className="w-4 h-4 text-cyan-400" />
            <span className="text-sm text-cyan-400 font-medium">Get In Touch</span>
          </div>
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-bold text-white mb-4">
            Contact Us
          </h2>
          <p className="max-w-2xl mx-auto text-gray-400 text-lg">
            If you're serious about building a predictable pipeline with accurate decision-maker data, 
            send us your target industry and criteria.
          </p>
        </div>

        <div className="grid lg:grid-cols-2 gap-12">
          {/* Left Column - CTA */}
          <div>
            <div className="p-8 rounded-2xl bg-gradient-to-br from-cyan-500/10 to-blue-500/10 border border-cyan-500/20 mb-8">
              <Calendar className="w-12 h-12 text-cyan-400 mb-6" />
              <h3 className="text-2xl font-bold text-white mb-4">
                Book a Free Consultation Today
              </h3>
              <p className="text-gray-400 mb-8 leading-relaxed">
                We'll outline a structured growth plan tailored to your goals. Let's discuss how we can 
                help you build a predictable pipeline with accurate decision-maker data.
              </p>
              <Button
                size="lg"
                className="bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 text-white font-semibold px-8 py-6 text-lg rounded-xl shadow-lg shadow-cyan-500/25 hover:shadow-cyan-500/40 transition-all group w-full sm:w-auto"
                onClick={() => window.open('https://www.facebook.com/people/The-Data-Harbour/61588302914588/', '_blank')}
              >
                <Facebook className="mr-2 w-5 h-5" />
                Connect on Facebook
                <ArrowRight className="ml-2 w-5 h-5 group-hover:translate-x-1 transition-transform" />
              </Button>
            </div>

            {/* Contact Info */}
            <div className="space-y-4">
              <div className="flex items-center gap-4 p-4 rounded-xl bg-white/[0.02] border border-white/5">
                <div className="w-12 h-12 rounded-lg bg-cyan-500/10 flex items-center justify-center">
                  <Mail className="w-5 h-5 text-cyan-400" />
                </div>
                <div>
                  <p className="text-sm text-gray-500">Email Us</p>
                  <p className="text-white font-medium">contact@thedataharbour.com</p>
                </div>
              </div>

              <div className="flex items-center gap-4 p-4 rounded-xl bg-white/[0.02] border border-white/5">
                <div className="w-12 h-12 rounded-lg bg-cyan-500/10 flex items-center justify-center">
                  <Phone className="w-5 h-5 text-cyan-400" />
                </div>
                <div>
                  <p className="text-sm text-gray-500">Call Us</p>
                  <p className="text-white font-medium">+1 (555) 123-4567</p>
                </div>
              </div>

              <div className="flex items-center gap-4 p-4 rounded-xl bg-white/[0.02] border border-white/5">
                <div className="w-12 h-12 rounded-lg bg-cyan-500/10 flex items-center justify-center">
                  <MapPin className="w-5 h-5 text-cyan-400" />
                </div>
                <div>
                  <p className="text-sm text-gray-500">Location</p>
                  <p className="text-white font-medium">Global Remote Services</p>
                </div>
              </div>
            </div>
          </div>

          {/* Right Column - About Summary */}
          <div className="p-8 rounded-2xl bg-white/[0.02] border border-white/5">
            <h3 className="text-xl font-semibold text-white mb-6">
              About Us – The Data Harbour
            </h3>
            <div className="space-y-4 text-gray-400 leading-relaxed">
              <p>
                At The Data Harbour, we help businesses grow smarter and faster through strategic lead 
                generation and high-quality web research. Our mission is simple:{' '}
                <span className="text-white font-medium">
                  deliver accurate, targeted, and conversion-ready data that fuels real business growth.
                </span>
              </p>
              <p>
                We specialize in B2B lead generation, market research, data sourcing, and prospect list 
                building tailored to your industry and goals. Whether you're a startup looking to scale 
                or an established company expanding into new markets, we provide the insights and connections 
                you need to succeed.
              </p>
            </div>

            <div className="mt-8 pt-8 border-t border-white/5">
              <p className="text-cyan-400 font-semibold text-lg">
                "At The Data Harbour, we don't just generate leads — we create opportunities. 
                Let's build your growth engine together."
              </p>
            </div>

            {/* Social Links */}
            <div className="mt-8">
              <p className="text-sm text-gray-500 mb-4">Follow us on</p>
              <div className="flex flex-wrap gap-3">
                <a
                  href="https://www.linkedin.com/company/the-data-harbour/"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex items-center gap-3 px-6 py-3 rounded-xl bg-[#0A66C2]/10 border border-[#0A66C2]/30 text-[#0A66C2] hover:bg-[#0A66C2]/20 transition-all"
                >
                  <Linkedin className="w-5 h-5" />
                  <span className="font-medium">LinkedIn</span>
                </a>
                <a
                  href="https://www.facebook.com/people/The-Data-Harbour/61588302914588/"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex items-center gap-3 px-6 py-3 rounded-xl bg-[#1877F2]/10 border border-[#1877F2]/30 text-[#1877F2] hover:bg-[#1877F2]/20 transition-all"
                >
                  <Facebook className="w-5 h-5" />
                  <span className="font-medium">Facebook</span>
                </a>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}
