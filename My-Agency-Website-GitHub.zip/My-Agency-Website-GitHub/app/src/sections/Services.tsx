import { 
  Users, 
  Linkedin, 
  Mail, 
  MessageSquare, 
  Share2, 
  Star,
  Database,
  Search,
  FolderInput,
  Newspaper,
  Settings,
  Puzzle,
  ShoppingCart,
  HardDrive,
  HeadphonesIcon
} from 'lucide-react'

const services = [
  {
    icon: Users,
    title: 'Lead Generation (B2B & B2C)',
    description: 'Targeted, verified prospect lists built according to your exact criteria. Every lead is accuracy-checked for better outreach performance.',
  },
  {
    icon: Linkedin,
    title: 'LinkedIn Lead Generation',
    description: 'Using LinkedIn Sales Navigator and advanced filters, we identify and connect you with relevant decision-makers.',
  },
  {
    icon: Mail,
    title: 'Email Outreach Campaigns',
    description: 'Personalized cold email campaigns designed to generate conversations and business opportunities.',
  },
  {
    icon: MessageSquare,
    title: 'LinkedIn Automation & Outreach',
    description: 'Automated yet controlled LinkedIn messaging, InMail campaigns, connection building, and relationship management.',
  },
  {
    icon: Share2,
    title: 'Social Media Lead Generation',
    description: 'Prospect sourcing and outreach across LinkedIn, Facebook, Instagram, and other platforms.',
  },
  {
    icon: Star,
    title: 'Influencer Research & Outreach',
    description: 'Identify and connect with influencers on YouTube, TikTok, Instagram, and Facebook for brand partnerships.',
  },
  {
    icon: Database,
    title: 'Email List Building',
    description: 'Clean, segmented, and verified email databases tailored to your target audience.',
  },
  {
    icon: Search,
    title: 'General Research Services',
    description: 'Company research, competitor analysis, contact discovery, and deep web research beyond basic copy-paste tasks.',
  },
  {
    icon: FolderInput,
    title: 'CRM/CMS Database Entry',
    description: 'Accurate data entry and structured CRM updates to maintain a clean and organized sales pipeline.',
  },
  {
    icon: Newspaper,
    title: 'Maintaining CRM Database of Media Contacts',
    description: 'Organizing, updating, and managing media contact databases for PR and outreach campaigns.',
  },
  {
    icon: Settings,
    title: 'CRM Management & Automation',
    description: 'Experience with Pipedrive, HubSpot, Airtable, Monday.com, Mailchimp, ActiveCampaign, and Zoho CRM. We build structured workflows and integrations for efficiency.',
  },
  {
    icon: Puzzle,
    title: 'Integration & Automation',
    description: 'CRM integrations, email automation, lead tracking, workflow setup, and system optimization.',
  },
  {
    icon: ShoppingCart,
    title: 'Product Listing Services',
    description: 'Professional product listing and data entry for Shopify, Amazon, eBay, and other eCommerce platforms.',
  },
  {
    icon: HardDrive,
    title: 'Data Entry & Data Mining',
    description: 'Structured data extraction, cleaning, formatting, and validation.',
  },
  {
    icon: HeadphonesIcon,
    title: 'Virtual Assistance',
    description: 'Reliable operational and administrative support to keep your backend organized.',
  },
]

export default function Services() {
  return (
    <section className="py-20 lg:py-28 bg-[#0a0f1a]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="text-center mb-16">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-cyan-500/10 border border-cyan-500/20 mb-6">
            <Settings className="w-4 h-4 text-cyan-400" />
            <span className="text-sm text-cyan-400 font-medium">What We Offer</span>
          </div>
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-bold text-white mb-4">
            Our Core Services
          </h2>
          <p className="max-w-2xl mx-auto text-gray-400 text-lg">
            Comprehensive data and lead generation solutions tailored to your business needs
          </p>
        </div>

        {/* Services Grid */}
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {services.map((service, index) => (
            <div
              key={index}
              className="group p-6 rounded-2xl bg-white/[0.02] border border-white/5 hover:border-cyan-500/30 hover:bg-white/[0.04] transition-all duration-300"
            >
              <div className="w-12 h-12 rounded-xl bg-cyan-500/10 flex items-center justify-center mb-4 group-hover:bg-cyan-500/20 group-hover:scale-110 transition-all">
                <service.icon className="w-6 h-6 text-cyan-400" />
              </div>
              <h3 className="text-lg font-semibold text-white mb-3 group-hover:text-cyan-400 transition-colors">
                {service.title}
              </h3>
              <p className="text-sm text-gray-500 leading-relaxed">
                {service.description}
              </p>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
