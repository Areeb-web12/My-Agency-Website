import { Check, User, Users, Quote } from 'lucide-react'

const beliefs = [
  'Quality over quantity',
  'Verified data over scraped noise',
  'Long-term partnerships over short-term tasks',
]

const leadership = [
  {
    name: 'Ali Raza',
    role: 'Chief Executive Officer (CEO)',
    description:
      'Ali Raza leads The Data Harbour with a clear vision: to build a results-driven company focused on quality, transparency, and long-term partnerships. With strong expertise in strategic planning and business development, he ensures that every campaign aligns with client objectives and delivers measurable ROI.',
  },
  {
    name: 'Areeb Rehman',
    role: 'Managing Director',
    description:
      'Areeb Rehman oversees daily operations and project execution, ensuring efficiency, accuracy, and client satisfaction at every stage. With a sharp focus on performance, systems, and team coordination, he drives operational excellence and ensures that every lead delivered meets the highest standards.',
  },
]

export default function About() {
  const scrollToContact = () => {
    const element = document.querySelector('#contact')
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' })
    }
  }

  return (
    <section className="py-20 lg:py-28 bg-[#0d121f]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="text-center mb-16">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-cyan-500/10 border border-cyan-500/20 mb-6">
            <User className="w-4 h-4 text-cyan-400" />
            <span className="text-sm text-cyan-400 font-medium">About Us</span>
          </div>
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-bold text-white mb-4">
            About The Data Harbour
          </h2>
        </div>

        {/* Main Content */}
        <div className="grid lg:grid-cols-2 gap-12 lg:gap-16 mb-20">
          {/* Left Column - Company Info */}
          <div>
            <div className="p-8 rounded-2xl bg-white/[0.02] border border-white/5">
              <Quote className="w-10 h-10 text-cyan-400/50 mb-4" />
              <p className="text-xl text-white font-medium mb-6 leading-relaxed">
                The Data Harbour was founded with one clear objective:{' '}
                <span className="text-cyan-400">
                  To help businesses grow through accurate data and structured client acquisition systems.
                </span>
              </p>
              <p className="text-gray-400 leading-relaxed mb-6">
                Founded by Ali Raza, a dedicated growth specialist with over 5 years of professional 
                experience, we have helped businesses across multiple industries build targeted prospect 
                lists, execute outreach campaigns, and streamline CRM systems.
              </p>
              <p className="text-gray-400 leading-relaxed">
                We don't rely on guesswork. We combine premium tools, manual research, and verification 
                systems to ensure every lead meets your targeting criteria.
              </p>
            </div>
          </div>

          {/* Right Column - Beliefs */}
          <div>
            <h3 className="text-xl font-semibold text-white mb-6">We believe in:</h3>
            <div className="space-y-4 mb-8">
              {beliefs.map((belief, index) => (
                <div
                  key={index}
                  className="flex items-center gap-4 p-4 rounded-xl bg-white/[0.02] border border-white/5"
                >
                  <div className="w-8 h-8 rounded-lg bg-cyan-500/10 flex items-center justify-center flex-shrink-0">
                    <Check className="w-4 h-4 text-cyan-400" />
                  </div>
                  <span className="text-gray-300 font-medium">{belief}</span>
                </div>
              ))}
            </div>

            <div className="p-6 rounded-xl bg-gradient-to-r from-cyan-500/10 to-blue-500/10 border border-cyan-500/20">
              <p className="text-gray-300 mb-4">
                If you are serious about building a predictable pipeline with accurate decision-maker data, 
                send us your target industry and criteria, and we will outline a clear plan tailored to your goals.
              </p>
              <button
                onClick={scrollToContact}
                className="text-cyan-400 font-medium hover:text-cyan-300 transition-colors"
              >
                Let's build something valuable →
              </button>
            </div>
          </div>
        </div>

        {/* Leadership Team */}
        <div>
          <div className="flex items-center gap-3 mb-8">
            <Users className="w-6 h-6 text-cyan-400" />
            <h3 className="text-2xl font-bold text-white">Leadership Team</h3>
          </div>

          <div className="grid md:grid-cols-2 gap-6">
            {leadership.map((leader, index) => (
              <div
                key={index}
                className="p-8 rounded-2xl bg-white/[0.02] border border-white/5 hover:border-cyan-500/30 transition-all"
              >
                <div className="w-16 h-16 rounded-full bg-gradient-to-br from-cyan-500 to-blue-600 flex items-center justify-center mb-6">
                  <span className="text-2xl font-bold text-white">
                    {leader.name.split(' ').map(n => n[0]).join('')}
                  </span>
                </div>
                <h4 className="text-xl font-semibold text-white mb-1">{leader.name}</h4>
                <p className="text-cyan-400 font-medium mb-4">{leader.role}</p>
                <p className="text-gray-400 leading-relaxed">{leader.description}</p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  )
}
