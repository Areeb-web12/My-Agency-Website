import express from "express";
import Contact from "../models/Contact.js";

const router = express.Router();

router.post("/", async (req, res) => {
  try {
    const { name, email, company, message } = req.body;

    const newContact = new Contact({
      name,
      email,
      company,
      message
    });

    await newContact.save();

    res.status(200).json({
      success: true,
      message: "Message received"
    });

  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

export default router;